# WebSIG Turístico do município de São José do Norte

Este WebSIG é um dos produtos elaborados no Trabalho de Conclusão de Curso intitulado: 
##### COMPARAÇÃO DE FERRAMENTAS PARA DESENVOLVIMENTO DE SISTEMAS DE INFORMAÇÕES GEOGRÁFICAS ONLINE (WEBSIG): ESTUDO DE CASO NO MUNICÍPIO DE SÃO JOSÉ DO NORTE/RS

>>

Trabalho de Conclusão de Curso apresentado como pré-requisito para a obtenção do Diploma de Técnico em Geoprocessamento do Instituto Federal de Educação, Ciência e Tecnologia do Rio Grande do Sul (IFRS).

Discente: Vitória Marca Santa Lucia - > [Linkedin] - [Lattes¹]
Orientador: Tiago Borges Gandra - > [ResearchGate] -  [Lattes²]
Co-orientadora: Júlia Nyland do Amaral - > [Lattes³]

Código em R disponível no [Github]

   [Linkedin]: <https://github.com/joemccann/dillinger>
   [ResearchGate]: <https://www.researchgate.net/profile/Tiago-Gandra-2>
   [Lattes¹]: <http://lattes.cnpq.br/0831819379858516>
   [Lattes²]: <http://lattes.cnpq.br/8370478243309846>
   [Lattes³]: <http://lattes.cnpq.br/9029087751290834>

[Github]: <>
